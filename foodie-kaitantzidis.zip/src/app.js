require('./js/main.js');
require('./scss/style.scss');
