# foodie

Static site for an imaginary food application for an exercise